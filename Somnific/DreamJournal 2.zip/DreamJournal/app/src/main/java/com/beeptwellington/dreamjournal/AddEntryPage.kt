package com.beeptwellington.dreamjournal

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_add_entry_page.*
import java.text.SimpleDateFormat
import java.util.*
import android.support.v4.content.res.ResourcesCompat
import android.view.animation.TranslateAnimation
import android.widget.TextView
/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//This class handles assign an entry to the dream database.
@Suppress("NAME_SHADOWING")
class AddEntryPage : AppCompatActivity() {
    private val dreamDatabase = DreamDbHandler(this, null, null, 1)
    private var happyFaceSelected = false
    private var sadFaceSelected = false
    private var angryFaceSelected = false
    private var nervousFaceSelected = false
    private var scaredFaceSelected = false
    private var currentUser : String? = null

    @SuppressLint("SimpleDateFormat", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_entry_page)
        setSupportActionBar(toolbar)
        supportActionBar!!.title = ""

        //get any information already entered, used for editing an entry.
        currentUser = intent.getStringExtra("user")
        val titleAlreadyEntered = intent.getStringExtra("title")
        val dreamAlreadyEntered = intent.getStringExtra("dream")
        val dayAlreadyEntered = intent.getStringExtra("day")
        var latLngOfLocationToSave = intent.getDoubleArrayExtra("location")
        val currentId = intent.getIntExtra("id", -1)
        val highlight = ResourcesCompat.getDrawable(resources, R.drawable.highlight, null)


        if(latLngOfLocationToSave != null){
            if(latLngOfLocationToSave[0] != -1.0 && latLngOfLocationToSave[1] != -1.0){
                val location = findViewById<TextView>(R.id.location)
                location.text = "Lat = " + latLngOfLocationToSave[0] + ", Long = " + latLngOfLocationToSave[1]
            }
        }

        //set the text if the user has already entered things before clicking on the location button.
        val title = findViewById<EditText>(R.id.title)
        title.setText(titleAlreadyEntered, TextView.BufferType.EDITABLE)

        val dream = findViewById<EditText>(R.id.dream)
        dream.setText(dreamAlreadyEntered, TextView.BufferType.EDITABLE)

        val day = findViewById<EditText>(R.id.day)
        day.setText(dayAlreadyEntered, TextView.BufferType.EDITABLE)

        val locationButton = findViewById<TextView>(R.id.location)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val happyFace = findViewById<ImageView>(R.id.happyFace)
        val sadFace = findViewById<ImageView>(R.id.sadFace)
        val angryFace = findViewById<ImageView>(R.id.angryFace)
        val nervousFace = findViewById<ImageView>(R.id.nervousFace)
        val scaredFace = findViewById<ImageView>(R.id.scaredFace)
        val moods : ArrayList<String> = ArrayList()

        locationButton.setOnClickListener{
            val intent = Intent(this, MapsActivity::class.java)
            //send all the information the user has entered so far...
            intent.putExtra("user", currentUser)
            intent.putExtra("id", currentId)
            intent.putExtra("title", title.text.toString())
            intent.putExtra("dream", dream.text.toString())
            intent.putExtra("day", day.text.toString())
            startActivity(intent)
        }

        //animate the faces to bounce
        val animation = TranslateAnimation(0.0f, 0.0f,
                15.0f, 0.0f)
        animation.duration = 300
        animation.repeatCount = 5000
        animation.repeatMode = 2

        happyFace.setOnClickListener{
            happyFaceSelected = !happyFaceSelected
            if(happyFaceSelected){
                happyFace.background = highlight
                happyFace.startAnimation(animation)
                moods.add("Happy")
            }else{
                moods.remove("Happy")
                happyFace.background = null
                happyFace.clearAnimation()
            }
        }

        sadFace.setOnClickListener{
            sadFaceSelected = !sadFaceSelected
            if(sadFaceSelected){
                moods.add("Sad")
                sadFace.background = highlight
                sadFace.startAnimation(animation)
            }else{
                moods.remove("Sad")
                sadFace.background = null
                sadFace.clearAnimation()
            }
        }

        angryFace.setOnClickListener{
            angryFaceSelected = !angryFaceSelected
            if(angryFaceSelected){
                moods.add("Angry")
                angryFace.background = highlight
                angryFace.startAnimation(animation)

            }else{
                moods.remove("Angry")
                angryFace.background = null
                angryFace.clearAnimation()
            }
        }

        nervousFace.setOnClickListener{
            nervousFaceSelected = !nervousFaceSelected
            if(nervousFaceSelected){
                moods.add("Anxious")
                nervousFace.background = highlight
                nervousFace.startAnimation(animation)

            }else{
                moods.remove("Anxious")
                nervousFace.background = null
                nervousFace.clearAnimation()
            }
        }

        scaredFace.setOnClickListener{
            scaredFaceSelected = !scaredFaceSelected
            if(scaredFaceSelected){
                moods.add("Scared")
                scaredFace.background = highlight
                scaredFace.startAnimation(animation)

            }else{
                moods.remove("Scared")
                scaredFace.background = null
                scaredFace.clearAnimation()
            }
        }

        //save all inputted information into the dream database.
        saveButton.setOnClickListener{
            //collect all information inputted.
            val titleText = findViewById<EditText>(R.id.title)
            val dreamText = findViewById<EditText>(R.id.dream)
            val dayText = findViewById<EditText>(R.id.day)
            val title = titleText.text.toString()
            val dream = dreamText.text.toString()
            val day = dayText.text.toString()
            val currentDate = SimpleDateFormat("MM/dd/yyyy").format(Calendar.getInstance().time)

            //if the user did not enter a location
            if(latLngOfLocationToSave == null){
                latLngOfLocationToSave = DoubleArray(2)
                latLngOfLocationToSave[0] = -1.0
                latLngOfLocationToSave[1] = -1.0
            }

            //check what moods are selected
            var moodString : String? = null
            for(i in 0 until moods.size){
                val mood = moods[i]
                if(moodString.equals(null)){
                    moodString = mood
                }else {
                    moodString = "$moodString, $mood"
                }
            }
            //add to database
            if(currentId != -1){
                dreamDatabase.deleteRowInTableDreams(currentId)
                dreamDatabase.addRowToTableDreams(Dream(currentId, currentUser, title, dream, day, moodString, latLngOfLocationToSave[0], latLngOfLocationToSave[1], currentDate))
            }else{
                dreamDatabase.addRowToTableDreams(Dream(currentUser, title, dream, day, moodString, latLngOfLocationToSave[0], latLngOfLocationToSave[1], currentDate))
            }

            val intent = Intent(this, EntriesPage::class.java)
            intent.putExtra("user", currentUser)
            startActivity(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_add_entry_page, menu)
        return true
    }

    // Handle action bar item clicks here.
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        return when (id) {
            R.id.action_delete -> {
                val intent = Intent(this, EntriesPage::class.java)
                intent.putExtra("user", currentUser)
                startActivity(intent)
                true
            }

            else -> {
                super.onOptionsItemSelected(item)
            }
        }
    }
}
