package com.beeptwellington.dreamjournal

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_entries_page.*
import android.widget.LinearLayout
import android.widget.TextView
/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//Displays the dreams the user has inputted.
class EntriesPage : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    var spinner : Spinner? = null
    private val dreamDatabase = DreamDbHandler(this, null, null, 1)
    private var currentUser : String? = null
    private var dreams : ArrayList<Dream> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entries_page)
        setSupportActionBar(toolbar)
        currentUser = intent.getStringExtra("user")
        supportActionBar!!.title = currentUser + "'s" + " Dream Journal"
    }

    //sets up the spinner
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_entries_page, menu)
        //set up the spinner
        val moodTags : ArrayList<String> = ArrayList()
        moodTags.add("Filter by mood")
        moodTags.add("Happy")
        moodTags.add("Sad")
        moodTags.add("Angry")
        moodTags.add("Scared")
        moodTags.add("Anxious")
        moodTags.add("None")
        val item = menu.findItem(R.id.spinner)
        spinner = item.actionView as Spinner
        spinner!!.onItemSelectedListener = this
        val dataAdapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, moodTags)
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner!!.adapter = dataAdapter
        return true
    }

    //handles toolbar clicks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId

        when (id) {
            R.id.addEntry -> {
                val intent = Intent(this, AddEntryPage::class.java)
                intent.putExtra("user", currentUser)
                startActivity(intent)
                return true
            }
            R.id.questionMark -> {
                val intent = Intent(this, InfoPage::class.java)
                startActivity(intent)
                return true
            }R.id.logOut -> {
                val intent = Intent(this, LoginPage::class.java)
                startActivity(intent)
                return true
            }
            else -> {
                return super.onOptionsItemSelected(item)
            }
        }
    }

    //Spinner method when something is clicked. This method populated the activity with entries from the database.
    override fun onItemSelected(parent: AdapterView<*>, view: View,
                                pos: Int, id: Long) {
        (parent.getChildAt(0) as TextView).setTextColor(Color.WHITE)
        (parent.getChildAt(0) as TextView).textSize = 16f

        val mood = parent.getItemAtPosition(pos).toString()
        val linearLayout = findViewById<LinearLayout>(R.id.entriesContainer)

        if (linearLayout.childCount > 0) {
            linearLayout.removeAllViews()
        }

        if(mood != "Filter by mood" && mood != "None"){
            dreams = filterDreams(currentUser, mood)
        }else{
            dreams = getDreams(currentUser)
        }

        var audio = MediaPlayer.create(this, R.raw.pageflip)
        val journalEntries : ArrayList<TextView> = ArrayList()

        //populate the activity with entries
        for(i in 0 until dreams.size) {
            val currentDream = dreams[i]
            val temp: TextView? = TextView(this)
            val seperationBar: TextView? = TextView(this)
            temp!!.text = currentDream.title + " - " + currentDream.date
            temp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32.0F)
            temp.setTextColor(Color.BLACK)
            temp!!.typeface = Typeface.create("casual", Typeface.NORMAL)

            temp.setOnClickListener {
                if (audio.isPlaying) {
                    audio.stop()
                    audio.release()
                    audio = MediaPlayer.create(this, R.raw.pageflip)
                }
                audio.start()

                val intent = Intent(this, DisplayEntryPage::class.java)
                intent.putExtra("dreamIndex", currentDream.id)
                intent.putExtra("user", currentUser)
                startActivity(intent)
            }

            seperationBar!!.text = " "
            seperationBar.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30.0F)

            //add the textview to the linearlayout
            linearLayout.addView(temp)
            linearLayout.addView(seperationBar)
            journalEntries.add(temp)
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>) {

    }

    //Search the dream database for dreams associated with that username
    private fun getDreams(username : String?) : ArrayList<Dream>{
        return dreamDatabase.searchTableDreams(username)
    }

    //Search the dream database for dreams associated with that username and mood.
    private fun filterDreams(username : String?, mood : String) : ArrayList<Dream>{
         return dreamDatabase.filterTableDreams(username, mood)
    }
}
