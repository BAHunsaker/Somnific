package com.beeptwellington.dreamjournal

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_create_account_page.*
import java.security.Key
import java.util.*
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//This class handles creating a new user account.
class CreateAccountPage : AppCompatActivity() {
    private val dreamDatabase = DreamDbHandler(this, null, null, 1)
    private var aes: AdvEncryptionStand = AdvEncryptionStand()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_account_page)
        setSupportActionBar(toolbar)
        supportActionBar!!.title = ""

        val warningText = findViewById<TextView>(R.id.warningText)
        val cancelButton = findViewById<Button>(R.id.cancelButton)
        val createAccountButton = findViewById<Button>(R.id.createAccountButton2)

        createAccountButton.setOnClickListener{
            val newUsername = findViewById<EditText>(R.id.newUsernameInput).text.toString()
            val newPassword = findViewById<EditText>(R.id.newPasswordInput).text.toString()

            val takenUser = dreamDatabase.searchForUser(newUsername)
            if(takenUser != null){
                println("takenUser " + takenUser.username)
                warningText.text = "This username is already taken, please enter a different one."
            }else{
                //encrypt the password
               val encryptedPassword = aes.crypt(Cipher.ENCRYPT_MODE, newPassword, aes.getKey())
                val keyString = android.util.Base64.encodeToString(aes.getKey().encoded, Base64.DEFAULT)

                dreamDatabase.addRowToTableUser(User(newUsername, encryptedPassword, keyString))
                val intent = Intent(this, LoginPage::class.java)
                startActivity(intent)
            }
        }

        cancelButton.setOnClickListener{
            val intent = Intent(this, LoginPage::class.java)
            startActivity(intent)
        }
    }

}
