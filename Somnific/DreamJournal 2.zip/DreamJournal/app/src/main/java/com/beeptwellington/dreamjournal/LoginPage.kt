package com.beeptwellington.dreamjournal

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_login_page.*
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//Handles login and decryption.
class LoginPage : AppCompatActivity() {
    private var aes : AdvEncryptionStand = AdvEncryptionStand()
    private val dreamDatabase = DreamDbHandler(this, null, null, 1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)
        setSupportActionBar(toolbar)
        supportActionBar!!.title = ""

        val loginButton = findViewById<Button>(R.id.loginButton)
        val newUserButton = findViewById<Button>(R.id.createAccountButton)
        val warningText = findViewById<TextView>(R.id.loginPageWarningText)
        val username = findViewById<EditText>(R.id.usernameInput)
        val password = findViewById<EditText>(R.id.passwordInput)

        newUserButton.setOnClickListener{
            val intent = Intent(this, CreateAccountPage::class.java)
            startActivity(intent)
        }

        //decrypt the password
        loginButton.setOnClickListener{
            val name = username.text.toString()
            val pass = password.text.toString()
            val user = dreamDatabase.searchForUser(name)
            if(user != null){
                val correctPassword = user.password

                //convert string in database to the correct key
                val keyString = user.key
                val byteKey = Base64.decode(keyString, Base64.DEFAULT)
                val key = SecretKeySpec(byteKey, 0, byteKey.size, "AES")

                val decryptedPasswordInput =  aes.crypt(Cipher.DECRYPT_MODE, correctPassword, key)
                if(pass == decryptedPasswordInput){
                    val intent = Intent(this, EntriesPage::class.java)
                    intent.putExtra("user", name)
                    startActivity(intent)
                }else{
                    warningText.text = "Invalid username or password"
                }
            }else{
                warningText.text = "Invalid username or password"
            }
        }
    }

}
