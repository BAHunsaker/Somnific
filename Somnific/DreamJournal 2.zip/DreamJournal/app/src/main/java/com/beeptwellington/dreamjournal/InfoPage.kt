package com.beeptwellington.dreamjournal

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_info_page.*
import android.view.animation.TranslateAnimation

/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//How to use the app
class InfoPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_info_page)
        setSupportActionBar(toolbar)
        supportActionBar!!.title = ""

        val image = findViewById<ImageView>(R.id.animatedSmile)

        val animation = TranslateAnimation(-400.0f, 400.0f,
                0.0f, 0.0f)
        animation.duration = 5000
        animation.repeatCount = 500
        animation.repeatMode = 2

        image.startAnimation(animation)
    }
}
