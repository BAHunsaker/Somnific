package com.beeptwellington.dreamjournal

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_display_entry_page.*

/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//Displays the dream entry from te database.
class DisplayEntryPage : AppCompatActivity() {

    private var dream : Dream? = null
    private var currentUser :String? = null
    var id : Int = -1

    /*fill out the dream text information by grabbing the extras from the intent sent from
    EntriesPage */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_entry_page)
        setSupportActionBar(toolbar)
        supportActionBar!!.title = ""

        id =intent.getIntExtra("dreamIndex", -1)
        currentUser = intent.getStringExtra("user")

        dream = findDream(id)

        //set the text
        val titleTextView = findViewById<TextView>(R.id.titleInfo)
        val dreamTextView = findViewById<TextView>(R.id.dreamInfo)
        val dayTextView = findViewById<TextView>(R.id.dayInfo)
        val locationTextView = findViewById<TextView>(R.id.locationInfo)
        val dateTextView = findViewById<TextView>(R.id.date)
        titleTextView.text = dream!!.title
        dreamTextView.text = dream!!.dream
        dayTextView.text = dream!!.day
        dateTextView.text = dream!!.date

        val locationLatitude = dream!!.latitude
        val locationLongitude = dream!!.longitude
        if(locationLatitude != -1.0 && locationLongitude != -1.0){
            locationTextView.text = "Lat = " + locationLatitude + ", Long = " + locationLongitude
        }

        //add moods pictures
        val moods = dream!!.mood
        if(moods != null){
            val moodArray = moods.split(",", " ")
            val linearLayout = findViewById<LinearLayout>(R.id.moodLinearLayout)

            for(k in 0 until moodArray.size){
                val myImage = ImageView(this)
                val current = moodArray[k]
                if(current == "Happy"){
                    myImage.setImageResource(R.drawable.happy)
                    linearLayout.addView(myImage)
                }
                if(current == "Sad"){
                    myImage.setImageResource(R.drawable.sad)
                    linearLayout.addView(myImage)
                }
                if(current == "Angry"){
                    myImage.setImageResource(R.drawable.angry)
                    linearLayout.addView(myImage)
                }
                if(current == "Anxious"){
                    myImage.setImageResource(R.drawable.nervous)
                    linearLayout.addView(myImage)
                }
                if(current == "Scared"){
                    myImage.setImageResource(R.drawable.scared)
                    linearLayout.addView(myImage)
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_display_entry_page, menu)
        return true
    }

    // Handle action bar item clicks here.
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return when (id) {
            R.id.editEntry -> {
                //send all information already inputted to edit the entry.
                val intent = Intent(this, AddEntryPage::class.java)
                intent.putExtra("user", currentUser)
                intent.putExtra("title", dream!!.title)
                intent.putExtra("dream", dream!!.dream)
                intent.putExtra("day", dream!!.day)
                intent.putExtra("id", dream!!.id)
                val latLngOfLocationToSave = DoubleArray(2)
                latLngOfLocationToSave[0] = dream!!.latitude
                latLngOfLocationToSave[1] = dream!!.longitude
                intent.putExtra("location", latLngOfLocationToSave)

                startActivity(intent)
                true
            }R.id.action_delete ->{
                deleteDream()
                val intent = Intent(this, EntriesPage::class.java)
                intent.putExtra("user", currentUser)
                startActivity(intent)
                return true
            }
            else -> {
                super.onOptionsItemSelected(item)
            }
        }
    }
    //finds the dream with a given id.
    private fun findDream(id : Int) : Dream?{
        val dreamDatabase = DreamDbHandler(this, null, null, 1)
        return dreamDatabase.searchForDream(id)
    }

    //deletes the dream
    private fun deleteDream(){
        val dreamDatabase = DreamDbHandler(this, null, null, 1)
        dreamDatabase.deleteRowInTableDreams(this.id)
    }
}
