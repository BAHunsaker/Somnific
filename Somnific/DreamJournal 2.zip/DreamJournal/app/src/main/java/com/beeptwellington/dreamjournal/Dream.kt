package com.beeptwellington.dreamjournal
/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//Dream for the database
class Dream {
    var id : Int = 0
    var username : String? = null
    var title : String? = null
    var dream : String? = null
    var day : String? = null
    var mood : String? = null
    var latitude : Double = -1.0
    var longitude : Double = -1.0
    var date : String? = null


    constructor(id : Int, username : String?, title : String?, dream : String?, day : String?, mood : String?, latitude : Double, longitude : Double, date : String?){
        this.id = id
        this.username = username
        this.title = title
        this.dream = dream
        this.mood = mood
        this.day = day
        this.latitude = latitude
        this.longitude = longitude
        this.date = date
    }

    constructor(username : String?, title : String?, dream : String?, day : String?, mood : String?, latitude : Double, longitude : Double, date : String?){
        this.username = username
        this.title = title
        this.dream = dream
        this.day = day
        this.mood = mood
        this.latitude = latitude
        this.longitude = longitude
        this.date = date
    }
}