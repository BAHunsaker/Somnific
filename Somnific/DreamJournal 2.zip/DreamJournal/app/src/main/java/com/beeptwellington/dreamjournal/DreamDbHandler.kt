package com.beeptwellington.dreamjournal

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//This class handles database functionality.
class DreamDbHandler(context: Context, name: String?,
                      factory: SQLiteDatabase.CursorFactory?, version: Int) :
        SQLiteOpenHelper(context, DATABASE_NAME,
                factory, DATABASE_VERSION){

    override fun onCreate(db: SQLiteDatabase) {
        val CREATE_TABLE = ("CREATE TABLE " +
                TABLE_DREAMS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY," + COLUMN_USERNAME2 + " TEXT," + COLUMN_TITLE + " TEXT," +
                COLUMN_DREAM + " TEXT," + COLUMN_DAY + " TEXT," + COLUMN_MOOD + " TEXT," + COLUMN_LATITUDE + " DOUBLE,"
                + COLUMN_LONGITUDE + " DOUBLE," + COLUMN_DATE + " TEXT" + ")")
        db.execSQL(CREATE_TABLE)

        val CREATE_TABLE2 = ("CREATE TABLE " +
                TABLE_USERS + "("
                + COLUMN_USERNAME + " TEXT PRIMARY KEY," + COLUMN_PASSWORD + " TEXT," + COLUMN_KEY + " TEXT" + ")")
        db.execSQL(CREATE_TABLE2)
    }

    //Resets database when a new version is introduced.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int,
                           newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DREAMS)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS)
        onCreate(db)
    }

    companion object {

        private val DATABASE_VERSION = 1
        private val DATABASE_NAME = "DreamsDb.db"

        val TABLE_DREAMS = "DreamsDb"
        val COLUMN_ID = "id"
        val COLUMN_USERNAME2 = "username2"
        val COLUMN_TITLE = "title"
        val COLUMN_DREAM = "dream"
        val COLUMN_DAY = "day"
        val COLUMN_MOOD = "mood"
        val COLUMN_LATITUDE = "latitude"
        val COLUMN_LONGITUDE = "longitude"
        val COLUMN_DATE = "date"

        val TABLE_USERS = "UserDb"
        val COLUMN_USERNAME = "username"
        val COLUMN_PASSWORD = "password"
        val COLUMN_KEY = "key"
    }

    fun addRowToTableDreams(info: Dream) {

        val values = ContentValues()
        if(info.id != 0){
            values.put(COLUMN_ID, info.id)
        }
        values.put(COLUMN_USERNAME2, info.username)
        values.put(COLUMN_TITLE, info.title)
        values.put(COLUMN_DREAM, info.dream)
        values.put(COLUMN_DAY, info.day)
        values.put(COLUMN_MOOD, info.mood)
        values.put(COLUMN_LATITUDE, info.latitude)
        values.put(COLUMN_LONGITUDE, info.longitude)
        values.put(COLUMN_DATE, info.date)

        val db = this.writableDatabase

        db.insert(TABLE_DREAMS, null, values)
        db.close()
    }

    fun addRowToTableUser(info: User) {
        val values = ContentValues()
        values.put(COLUMN_USERNAME, info.username)
        values.put(COLUMN_PASSWORD, info.password)
        values.put(COLUMN_KEY, info.key)

        val db = this.writableDatabase
        db.insert(TABLE_USERS, null, values)
        db.close()
    }

    fun searchForDream(id : Int) : Dream? {
        val query = "SELECT * FROM $TABLE_DREAMS WHERE $COLUMN_ID = \"$id\""

        val db = this.writableDatabase

        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            val id = cursor.getInt(0)
            val username = cursor.getString(1)
            val title = cursor.getString(2)
            val dream = cursor.getString(3)
            val day = cursor.getString(4)
            val mood = cursor.getString(5)
            val latitude = cursor.getString(6).toDouble()
            val longitude = cursor.getString(7).toDouble()
            val date = cursor.getString(8)
            val result = Dream(id, username, title, dream, day, mood, latitude, longitude, date)
            return result
        }
        db.close()
        cursor.close()
        return null
    }

    fun searchForUser(username: String?): User? {
        val query = "SELECT * FROM $TABLE_USERS WHERE $COLUMN_USERNAME = \"$username\""

        val db = this.writableDatabase

        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            val username = cursor.getString(0)
            val password = cursor.getString(1)
            val key = cursor.getString(2)
            val result = User(username, password, key)
            println("user found in searchForUser: " + username + " " + password)
            return result
        }
        db.close()
        cursor.close()
        return null
    }

    fun deleteRowInTableDreams(id: Int): Boolean {
        var result = false

        val query = "SELECT * FROM $TABLE_DREAMS WHERE $COLUMN_ID = \"$id\""

        val db = this.writableDatabase

        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            val id = Integer.parseInt(cursor.getString(0))
            db.delete(TABLE_DREAMS, COLUMN_ID + " = ?",
                    arrayOf(id.toString()))
            cursor.close()
            result = true
        }
        db.close()
        cursor.close()
        return result
    }

    fun filterTableDreams(username : String?, mood : String) : ArrayList<Dream>{
        val results : ArrayList<Dream> = ArrayList()
        val query = "SELECT * FROM $TABLE_DREAMS WHERE $COLUMN_USERNAME2 = \"$username\" AND $COLUMN_MOOD LIKE \"%$mood%\" ORDER BY ID DESC"
        val db = this.writableDatabase
        val cursor = db.rawQuery(query, null)
        try {
            while (cursor.moveToNext()) {
                val id = cursor.getInt(0)
                val username = cursor.getString(1)
                val title = cursor.getString(2)
                val dream = cursor.getString(3)
                val day = cursor.getString(4)
                val mood = cursor.getString(5)
                val latitude = cursor.getString(6).toDouble()
                val longitude = cursor.getString(7).toDouble()
                val date = cursor.getString(8)
                val place = Dream(id, username, title, dream, day, mood, latitude, longitude, date)
                results.add(place)
            }
        } finally {
            cursor.close()
        }
        db.close()
        cursor.close()
        return(results)
    }

    //display function
    fun searchTableDreams(username : String?) : ArrayList<Dream>{
        val results : ArrayList<Dream> = ArrayList()
        val query = "SELECT * FROM $TABLE_DREAMS WHERE $COLUMN_USERNAME2 = \"$username\" ORDER BY ID DESC"
        val db = this.writableDatabase
        val cursor = db.rawQuery(query, null)

        try {
            while (cursor.moveToNext()) {
                val id = cursor.getInt(0)
                val username = cursor.getString(1)
                val title = cursor.getString(2)
                val dream = cursor.getString(3)
                val day = cursor.getString(4)
                val mood = cursor.getString(5)
                val latitude = cursor.getString(6).toDouble()
                val longitude = cursor.getString(7).toDouble()
                val date = cursor.getString(8)
                val place = Dream(id, username, title, dream, day, mood, latitude, longitude, date)
                results.add(place)
            }
        } finally {
            cursor.close()
        }
        db.close()
        cursor.close()
        return(results)
    }
}