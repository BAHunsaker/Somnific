package com.beeptwellington.dreamjournal

import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.widget.Button
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions

/* ********************************* */
/* Program: Somnific                 */
/* Description: This is a dream journal
 * app that lets the user input dreams
  * including the mood it invoked, the day
  * they had, and their location. The dreams
  * are stored in a database.        */
/* Author: Bailey Hunsaker
 * Notes: My special feature is the
           highlighting of the mood
           emojis when you click them*/
/* Reference: Jianna Zhang

              Audio file take from
              https://www.soundjay.com
              /page-flip-sounds-1.html

          Developer.Android.com

          https://www.techotopia.com
          /index.php/A_Kotlin_Android
          _SQLite_Database_Tutorial */

/* Last Modified: June 13 2018      */
/* ********************************* */

//allows the user to add their current location or click on a location to add to their dream.
class MapsActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener {


    override fun onMarkerClick(p0: Marker?): Boolean {
        return false
    }

    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var lastLocation: Location
    private var locationToSave : LatLng? = null
    private var currentUser : String? = null
    private var title : String? = null
    private var dream : String? = null
    private var day : String? = null
    private var currentId = -1

    companion object {
        private const val LOCATION_PERMISSION_REQUEST_CODE = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        fusedLocationClient =  LocationServices.getFusedLocationProviderClient(this)
        currentUser = intent.getStringExtra("user")
        currentId = intent.getIntExtra("id", -1)
        title = intent.getStringExtra("title")
        dream = intent.getStringExtra("dream")
        day = intent.getStringExtra("day")
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.setOnMarkerClickListener(this)
        setUpMap()

        if(ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){

            mMap.isMyLocationEnabled = true
            //grab last know location
            fusedLocationClient.lastLocation.addOnSuccessListener(this) { location : Location? ->
                if (location != null) {
                    lastLocation = location
                    val currentLatLng = LatLng(location.latitude, location.longitude)
                    mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12f))
                }
            }
        }

        val currentLocationButton = findViewById<Button>(R.id.useCurrentLocationButton)

        //save the current location
        currentLocationButton.setOnClickListener{
            locationToSave = LatLng(lastLocation.latitude, lastLocation.longitude)
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(locationToSave, 12f))
            if (locationToSave == null){
                locationToSave = LatLng(-1.0, -1.0)
            }
            locationToSave = locationToSave
            val latLngOfLocationToSave = DoubleArray(2)
            latLngOfLocationToSave[0] = locationToSave!!.latitude
            latLngOfLocationToSave[1] = locationToSave!!.longitude

            val intent = Intent(this, AddEntryPage::class.java)
            intent.putExtra("user", currentUser)
            intent.putExtra("id", currentId)
            intent.putExtra("location", latLngOfLocationToSave)
            intent.putExtra("title", title.toString())
            intent.putExtra("dream", dream.toString())
            intent.putExtra("day", day.toString())
            startActivity(intent)
        }

        //Lets you choose a location to save on the map and places a marker
        mMap.setOnMapClickListener({
            val options = MarkerOptions()
            options.position(it)
            options.title("Lat = " + it.latitude + ", Long = " + it.longitude)
            val marker = mMap.addMarker(options)
            locationToSave = LatLng(it.latitude, it.longitude)
        })

        val doneButton = findViewById<Button>(R.id.doneButton)
        //send the LatLng to addEntryPage
        doneButton.setOnClickListener{
            if (locationToSave == null){
                locationToSave = LatLng(-1.0, -1.0)
            }
            locationToSave = locationToSave
            val latLngOfLocationToSave = DoubleArray(2)
            latLngOfLocationToSave[0] = locationToSave!!.latitude
            latLngOfLocationToSave[1] = locationToSave!!.longitude

            val intent = Intent(this, AddEntryPage::class.java)
            intent.putExtra("user", currentUser)
            intent.putExtra("id", currentId)
            intent.putExtra("location", latLngOfLocationToSave)
            intent.putExtra("title", title.toString())
            intent.putExtra("dream", dream.toString())
            intent.putExtra("day", day.toString())
            startActivity(intent)
        }
    }

    //ask for permissions
    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), LOCATION_PERMISSION_REQUEST_CODE)
            return
        }
    }
}
